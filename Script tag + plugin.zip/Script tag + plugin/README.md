# 💬 Cognigy Webchat Integration with Feedback Plugin

This setup integrates the **Cognigy.AI Webchat** widget into any web project and extends it with a **Like/Dislike feedback plugin** for collecting message ratings.

The integration is fully error-safe thanks to structured `try/catch` handling and detailed console logging.

---

## ⚙️ Installation Guide

Follow these steps to install and integrate the chatbot into your project:

### 1️⃣ Copy Files
Save the following folder structure into your project repository:
```
/project
├── AI-Agent
    ├── /like-feedback
    │ └── script.js
    │ └── style.css
    ├── index.js
    └── README.md
```

### 2️⃣ Include the Script in Your HTML Template
Add this line to the HTML templates where you want the chatbot to appear:
```<script src="./index.js"></script>```

### 3️⃣ Start Your Application
Open your page in the browser — the Webchat will load automatically.
If everything is working correctly, you’ll see this log in the console:
✅ Like/Dislike plugin loaded
✅ like-feedback script loaded


# 🧠 Error Handling & Logging Overview

This project contains two main scripts that together provide a stable Cognigy Webchat integration with detailed runtime diagnostics.

1. **`initTariffBot.js`** – initializes the Cognigy Webchat client, manages sessions, and dynamically loads additional scripts.  
2. **`like-feedback/script.js`** – adds Like/Dislike buttons to each bot message and sends feedback events to Cognigy.

Both scripts use **structured `try/catch` blocks** and console logging to ensure all critical operations are monitored and recoverable.

---

## ⚙️ General Behavior

- Every main code section is wrapped in `try/catch`.
- All caught errors are logged in the browser console.
- Execution continues even if a specific part fails.
- Each log entry uses a **consistent emoji prefix**:
  - ✅ – success or completion notice  
  - ⚠️ – non-critical warning  
  - ❌ – critical error that prevents part of the logic from running  

---

## 🧩 1. `loadWebchatScript()`

**Purpose:** Dynamically loads the official `webchat.js` from the Cognigy GitHub releases and local styles.

**Checks:**
- ✅ Confirms `<script>` and `<link>` element creation.
- ✅ Executes the callback once the script and styles is fully loaded.
- ⚠️ Logs an error if the script or styles fails to load.

**Possible log output:**
- ❌ Failed to load webchat.js
- ❌ Failed to load styles
- ❌ Error in loadWebchatScript: `details`
- ❌ Error in styles: `details`

---

## 🧩 2. `initTariffBot()`

Main entry point for initializing the bot and handling local session state.

### 🔹 LocalStorageWrapper

Responsible for safe interaction with `window.localStorage`.

**Checks:**
- ⚠️ `getItem()` – verifies read access to stored data.  
- ⚠️ `setItem()` – ensures JSON serialization and write access.  
- ⚠️ `removeItem()` – safely deletes keys from localStorage.  

**Example log:**
- ⚠️ Failed to get item from localStorage: `details`

---

### 🔹 widgetState

Controls whether the chat widget is currently open or closed.

**Checks:**
- ⚠️ `isOpen()` – verifies access to the `storage` object.  
- ⚠️ `setWebchatOpened()` – safely updates the state and persists it to localStorage.

**Example log:**
- ⚠️ widgetState.isOpen failed: `details`

---

### 🔹 generateSessionID()

Generates a unique session ID based on a random 9-digit number and current timestamp.

**Checks:**
- ⚠️ Any failure in random generation or date formatting.  
- ❌ Returns `"unknown-session"` if generation fails.

**Example log:**
- ❌ Error generating session ID: `details`

---

### 🔹 Session Handling

Handles restoring or creating a new chat session.

**Checks:**
- ⚠️ Validation of existing session data and timestamps.  
- ⚠️ Creating a new session and storing it in localStorage.  
- ❌ Logs if session initialization fails entirely.

**Example log:**
- ⚠️ Error validating existing session: `details`
- ❌ Error creating new session: `details`

---

### 🔹 Webchat Initialization

Executes the actual Cognigy `initWebchat()` call and binds event listeners.

**Checks:**
- ❌ Catch block around the entire initialization sequence.  
- ⚠️ Gracefully logs if event handlers or message listeners throw exceptions.  
- ✅ Loads the additional Like/Dislike plugin after successful initialization.

**Example logs:**
-✅ like-feedback script loaded
- ❌ Error initializing webchat: `details`
- ❌ Error in registerAnalyticsService event: `details`
- ⚠️ Error while opening webchat: `details`

---

## 🧩 3. `like-feedback/script.js`

This module attaches Like 👍 and Dislike 👎 buttons to each bot message and sends structured feedback events to Cognigy.

**Main Features:**
- Dynamically attaches buttons to new and restored bot messages.
- Uses `localStorage` to persist `message_id` mappings.
- Prevents duplicate button rendering via `.likebar` check.
- Sends structured `message_rating_event` payloads back to Cognigy.

### ✅ Safety & Logging

Each major step is wrapped with try/catch to prevent plugin crashes.

**Monitored operations:**
- Attaching Like/Dislike buttons to the DOM.  
- Handling click events and sending feedback.  
- Reacting to `incoming-message` and `webchat/open` events.  
- Restoring buttons after page reloads or session restore.

**Example logs:**
- ✅ Like/Dislike plugin loaded
- ♻️ Like/Dislike re-applied on restored messages: 12
- 👍 Like/Dislike added for new message: abc123
- ❌ Error attaching Like/Dislike to new message: `details`
- ❌ Error sending feedback: `details`


---

## 🧩 4. Logging Summary

| Emoji | Severity | Meaning |
|:------:|:----------|:--------|
| ✅ | Info | Successful operation or completion |
| ⚠️ | Warning | Non-critical issue – execution continues |
| ❌ | Error | Critical issue – part of logic skipped |
| ♻️ | Info | Re-applied / restored operation |

---

## 🧩 5. Recovery Logic

If any part of the flow fails:
- The failure is **logged but not fatal**.
- Initialization continues whenever possible.
- Users can refresh the page to re-init safely.
- The Like/Dislike plugin is **isolated**, so feedback errors never block chat rendering.

---

## 🧾 Notes

- All logs are visible in **browser DevTools → Console**.  
- The structure allows for quick debugging during deployment.  

---

# Task Tracking

## Completed Tasks

1. Session Initialization and Handling
**Asignee**: Andrii
**Objective**: Implement logic to initialize and manage chat sessions.
**Details**: Ensure sessions are restored or created anew, handle session expiration, and manage session state using localStorage.
**Outcome**: Sessions are reliably initialized and managed, with appropriate logging for errors and warnings.

2. Creation of Custom Plugin for Like/Dislike Buttons
**Asignee**: Andrii
**Objective**: Develop a plugin to add Like and Dislike buttons to bot messages.
**Details**: Attach buttons dynamically to each message, prevent duplicate rendering, and persist button state using localStorage.
**Outcome**: Buttons are successfully added to messages, with feedback events sent to Cognigy.

3. Event to Send Metadata to Cognigy on Button Press
**Asignee**: Andrii
**Objective**: Implement event handling to send feedback metadata to Cognigy.
**Details**: Capture button clicks, disable buttons post-click, and send structured feedback events.
**Outcome**: Feedback events are reliably sent, with error handling for network issues.

## Future Tasks

1. Events to Send Metadata on Website Page Changes
**Asignee**: 
**Objective**: Implement events to capture and send metadata when users navigate between pages.
**Details**: Detect page changes, collect relevant metadata, and send events to Cognigy.
**Task Requirements**: Develop logic to monitor page changes, define metadata structure, and ensure event reliability.

2. Events to Send Offer IDs to Cognigy
**Asignee**: 
**Objective**: Implement events to send offer IDs to Cognigy when specific actions occur.
**Details**: Capture offer-related actions, extract offer IDs, and send structured events to Cognigy.
**Task Requirements**: Define triggers for offer ID events, ensure accurate ID extraction, and implement error handling.

3. Integration of the Script into the Website
**Asignee**: 
**Objective**: Integrate the chatbot script into the website's HTML templates.
**Details**: Ensure the script is included in all relevant pages and not in the unwanted ones as defined in the CDD, verify compatibility with existing site elements, and test loading behavior as well as the persistence of the chat across page refreshes.
**Task Requirements**: Coordinate with web development team, test script integration, and resolve any conflicts.

4. Integration Testing of Functionality
**Asignee**: 
**Objective**: Conduct comprehensive testing of the chatbot's functionality and integration.
**Details**: Test for correct behavior, error handling, and user experience across different scenarios along the test defined down below.
**Task Requirements**: Develop test cases, execute tests, document results, and address any issues identified.

---

# ✅ Test Cases for Cognigy Webchat + Like/Dislike Plugin

---

## 🧩 Section 1 — Webchat Script Loading

### **Test Case 1.1 — Successful Webchat Script Load**
**Steps:**
1. Include `<script src="./index.js"></script>` in an HTML page.
2. Open the page in the browser.

**Expected Result:**
- Console shows:  
✅ Like/Dislike plugin loaded
✅ like-feedback script loaded
- The webchat icon/widget appears in the bottom corner.

---

## 🧩 Section 2 — Session Handling

### **Test Case 2.1 — Existing Session Restoration**
**Steps:**
1. Open the chat, send at least one message.
2. Refresh the page within 24 hours (keep `localStorage` intact).

**Expected Result:**
- Console shows:  
♻️ Like/Dislike re-applied on restored messages: `number`
- Old chat messages reappear.
- Like/Dislike buttons are reattached under each bot message.

---

### **Test Case 2.2 — Expired Session**
**Steps:**
1. Manually edit the timestamp inside `localStorage` → `SESSIONID` to simulate an expired session.
2. Refresh the page.

**Expected Result:**
- Console shows:
⚠️ Error validating existing session: `details`
❌ Error creating new session: `details`
- New chat session starts automatically.

---

### **Test Case 2.3 — localStorage Unavailable**
**Steps:**
1. Run browser in Incognito/Private mode with localStorage blocked.
2. Open the page.

**Expected Result:**
- Console shows warnings:
⚠️ Failed to set item in localStorage
⚠️ Failed to get item from localStorage
- The chatbot still loads with a temporary session ID.

---

## 🧩 Section 3 — Like/Dislike Buttons Behavior

### **Test Case 3.1 — Buttons Appear Under Bot Messages**
**Steps:**
1. Trigger a message from the bot.
2. Observe under the bot message bubble.

**Expected Result:**
- A Like 👍 and Dislike 👎 button pair appears below the message.
- Console logs:
👍 Like/Dislike added for new message: `message_id`

---

### **Test Case 3.2 — Feedback Sent Successfully**
**Steps:**
1. Click the 👍 or 👎 button.
2. Inspect browser console.

**Expected Result:**
- Buttons become disabled and highlighted.
- Console shows:
Message `message_id` 👍 Text: `message_text`
- A `message_rating_event` payload is visible in network logs.

---

### **Test Case 3.3 — Double Click Prevention**
**Steps:**
1. Click a Like or Dislike button multiple times.

**Expected Result:**
- Only the first click registers.
- Buttons remain disabled.
- No duplicate payloads sent.

---

### **Test Case 3.4 — Feedback Send Failure**
**Steps:**
1. Temporarily block the network (offline mode).
2. Click 👍 or 👎.

**Expected Result:**
- Console shows:
❌ Error sending feedback: `details`
- Buttons remain disabled.

---

## 🧩 Section 4 — DOM and Restore Behavior

### **Test Case 4.1 — Reapply Buttons on Reload**
**Steps:**
1. Open chat, receive multiple bot messages.
2. Refresh the page.

**Expected Result:**
- Like/Dislike buttons reappear under all previous messages.
- Console logs:
♻️ Like/Dislike re-applied on restored messages: `count`

---

### **Test Case 4.2 — Duplicate Buttons Prevention**
**Steps:**
1. Refresh multiple times or trigger repeated `webchat/open` events.

**Expected Result:**
- Each bot message contains only **one** pair of Like/Dislike buttons.
- No console warnings.

---

## 🧩 Section 5 — Console Log Sanity Check

### **Test Case 5.1 — Normal Run**
**Expected Console Sequence:**
✅ Like/Dislike plugin loaded
✅ like-feedback script loaded
♻️ Like/Dislike re-applied on restored messages: `count`
👍 Like/Dislike added for new message: `message_id`
Message `id` 👍 Text: `text`


