function loadWebchatScript(callback) {
    try {
        const script = document.createElement("script");
        script.src = "https://github.com/Cognigy/Webchat/releases/latest/download/webchat.js";
        script.onload = callback;
        script.onerror = () => console.error("❌ Failed to load webchat.js");
        document.head.appendChild(script);
    } catch (err) {
        console.error("❌ Error in loadWebchatScript:", err);
    }
    try {
        const styles = document.createElement("link");
        styles.src = "../like-feedback/style.css";
        styles.onload = callback;
        styles.onerror = () => console.error("❌ Failed to load styles");
        document.head.appendChild(styles);
    } catch (err) {
        console.error("❌ Error in styles:", err);
    }
}

function initTariffBot() {
    try {
        //Wrapper function to access the local storage of the browser. Main aim of the functions is to harmonize the access to ensure proper utilization.
        var localStorageWrapper = {
            /**
             * Obtains and returns the item of the localStorage via provided key
             * @param {String} storageKey Key of the item to be retrieved
             * @return {String} The item of the local storage stored under the provided key
             */
            getItem: function (storageKey) {
                try {
                    return JSON.parse(window.localStorage.getItem(storageKey));
                } catch (err) {
                    console.warn("⚠️ Failed to get item from localStorage:", err);
                    return null;
                }
            },

            /**
             * Sets the value to an item of the localStorage via provided key and data
             * @param {String} storageKey Key of the item to set the data to
             * @param {String} data Data to be stored
             */
            setItem: function (storageKey, data) {
                try {
                    return window.localStorage.setItem(storageKey, JSON.stringify(data));
                } catch (err) {
                    console.warn("⚠️ Failed to set item in localStorage:", err);
                }
            },

            /**
             * Removes an item from the localStorage via key
             * @param {String} storageKey Key of the item to remove from the localStorage
             */
            removeItem: function (storageKey) {
                try {
                    window.localStorage.removeItem(storageKey);
                } catch (err) {
                    console.warn("⚠️ Failed to remove item from localStorage:", err);
                }
            }
        };

        //Functions to check the state of the webchat (isOpen, setWebchatOpened)
        var widgetState = {
            /**
             * Accesses the storage to assess whether the webchat is currently open
             * @return {Boolean} Whether the webchat is currently open. True := Webchat is open ; False := Webchat is not open.
             */
            isOpen: function () {
                try {
                    return storage.webchatOpened === true;
                } catch (err) {
                    console.warn("⚠️ widgetState.isOpen failed:", err);
                    return false;
                }
            },

            /**
             * Updates the storage and localStorage on whether the webchat is currently open or not
             * @param {Boolean} isOpen Whether the webchat is currently open or not. True := Webchat is open ; False := Webchat is not open.
             */
            setWebchatOpened: function (isOpen) {
                try {
                    storage.webchatOpened = isOpen;
                    localStorageWrapper.setItem(features.botIdentifier, storage);
                } catch (err) {
                    console.warn("⚠️ widgetState.setWebchatOpened failed:", err);
                }
            }
        }

        /**
         * Generates the sessionId based on a random component and the current timestamp (e.g. 5780917982024-11-05T13:37:24).
         * @return {String} the unique sessionId
         */
        var generateSessionID = function () {
            try {
                // Generate a 9-digit random number and take the current date up until the seconds
                var nineDigitRandomNumber = "" + Math.floor(1000000000 * Math.random());
                var newDate = new Date().toISOString().slice(0, 19);

                // Return the sessionId
                return nineDigitRandomNumber + newDate;
            } catch (err) {
                console.error("❌ Error generating session ID:", err);
                return "unknown-session";
            }
        }

        var features = {

            // The URL of the bot to connect to. Consists of the Cognigy instance and an endpoint.
            endpoint_url: "https://endpoint-enbw-test.cognigy.cloud/1763661acd9440c2c5cbfeab1057a7892d7116b2eb0b65c570d9a4ac931e65e9",

            // Unique identifier for the localStorage (e.g. page constant). This ensures that multiple bots can be hosted on sites which share the same local storage.
            botIdentifier: "tariff-bot",

            // If keep_conversations is enabled, the conversation is kept when the user refreshes or closes the window and reopens the page (IMPORTANT: localStorage must not be deleted).
            keepConversations: true,

            // Maximum duration for keeping conversations in hours.
            keepConversations_max: 24,

            // If sendMetadata is true, then metadata will be sent to Cognigy.
            sendMetadata: false,

            // Defines the object which is sent to Cogngiy.
            sendMetadata_object:
            {
                "action": "sendMetadata",
                "body": {
                    "pageConstant": window.location.href,
                }
            }
        }

        let storage;
        try {
            // JSON property which stores the settings (e.g. sessionId, inputFieldLastState). If one has already been created, use it. Otherwise, start with an empty object.
            storage = localStorageWrapper.getItem(features.botIdentifier) || {};
        } catch (err) {
            console.warn("⚠️ Failed to load storage:", err);
            storage = {};
        }

        let sessionId;

        // Check if a sessionId is already stored in the localStorage. Furthermore, assert that the feature to keep sessions alive is enabled.
        try {
            if (storage.SESSIONID && features.keepConversations && features.keepConversations_max) {

                // Close the webchat widget
                widgetState.setWebchatOpened(false);

                // Determine the max date of the session (derived by features.keepConversations_max) and the current date.
                var max_date = new Date(storage.SESSIONID.slice(-19)).getTime() + features.keepConversations_max * 60 * 60 * 1000;
                var currentDate = new Date(new Date().toISOString().slice(0, 19)).getTime();

                // If the session has not been open longer than allowed, use the existing session.
                if (max_date >= currentDate) {
                    sessionId = storage.SESSIONID;
                }
            }
        } catch (err) {
            console.warn("⚠️ Error validating existing session:", err);
        }

        // In case there was no previously stored sessionId or we do not want to restore a session after refreshing, generate one and store it into localStorage.
        try {
            if (!sessionId) {
                storage = {};
                sessionId = generateSessionID();
                storage.SESSIONID = sessionId;
                localStorageWrapper.setItem(features.botIdentifier, storage);
            }
        } catch (err) {
            console.error("❌ Error creating new session:", err);
        }

        // Call the initWebchat function to connect to and load the bot.
        try {
            initWebchat(
                features.endpoint_url,
                {
                    sessionId: sessionId,
                },
                function (webchat) {
                    try {
                        window.webchat = webchat;

                        // Listen to certain events from the webchat.
                        webchat.registerAnalyticsService(function (event) {
                            try {
                                if (event.type === "webchat/close") {
                                    widgetState.setWebchatOpened(false);
                                }

                                if (event.type === "webchat/open") {
                                    if (features.sendMetadata && !storage.metaDataSent) {
                                        webchat.sendMessage("", features.sendMetadata_object);
                                        storage.metaDataSent = true;
                                        localStorageWrapper.setItem(features.botIdentifier, storage);
                                    }
                                    widgetState.setWebchatOpened(true);
                                }

                                if (event.type === "webchat/incoming-message") {
                                    if (features.sendMetadata && event.payload && event.payload.data && event.payload.data.action === "requestMetaData") {
                                        webchat.sendMessage("", features.sendMetadata_object);
                                    }
                                }
                            } catch (err) {
                                console.error("❌ Error in registerAnalyticsService event:", err);
                            }
                        });

                        // If the webchat has a certain parameter, open the webchat.
                        try {
                            if (
                                window.location.href.indexOf("open_window=true") !== -1 ||
                                window.location.href.indexOf("openchat") !== -1 ||
                                widgetState.isOpen()
                            ) {
                                webchat.open();
                            }
                        } catch (err) {
                            console.warn("⚠️ Error while opening webchat:", err);
                        }

                        try {
                            const afterInitScript = document.createElement("script");
                            afterInitScript.src = "./like-feedback/script.js";
                            afterInitScript.onload = () => console.log("✅ like-feedback plugin loaded");
                            afterInitScript.onerror = () => console.error("❌ Failed to load like-feedback plugin");
                            document.body.appendChild(afterInitScript);
                        } catch (err) {
                            console.error("❌ Error loading afterInitScript:", err);
                        }

                    } catch (err) {
                        console.error("❌ Error during webchat initialization callback:", err);
                    }
                }
            );
        } catch (err) {
            console.error("❌ Error initializing webchat:", err);
        }

    } catch (err) {
        console.error("❌ Fatal error in initTariffBot:", err);
    }
}

loadWebchatScript(initTariffBot);
