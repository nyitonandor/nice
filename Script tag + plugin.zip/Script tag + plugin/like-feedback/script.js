/**
 * Waits until the webchat instance is available on the window object before initializing the plugin.
 * This ensures that the webchat is fully loaded before attaching the Like/Dislike buttons functionality.
 */
const waitForWebchat = setInterval(() => {
  try {
    // Check if webchat has been initialized
    if (!window.webchat) return;
    clearInterval(waitForWebchat);

    const webchat = window.webchat;
    console.log("✅ Like/Dislike plugin loaded");

    /**
     * Creates and attaches Like/Dislike buttons to a given bot message element.
     * @param {HTMLElement} messageElement The DOM element representing the bot message.
     * @param {String} text The text content of the bot message.
     * @param {Object} webchat The Cognigy webchat instance to send feedback messages.
     */
    function addLikeDislikeButtons(messageElement, text, webchat) {
      try {
        const bubble = messageElement.querySelector(".chat-bubble");
        if (!bubble || bubble.parentElement.querySelector(".likebar")) return;

        const messageId = localStorage.getItem(messageElement.getAttribute("data-message-id")) || "";

        // Create container for the Like/Dislike buttons
        const bar = document.createElement("div");
        bar.classList.add("likebar");

        // Create Like button
        const like = document.createElement("button");
        like.classList.add("like-btn");
        like.textContent = "👍 Like";

        // Create Dislike button
        const dislike = document.createElement("button");
        dislike.classList.add("dislike-btn");
        dislike.textContent = "👎 Dislike";

        // Append buttons to the container and insert after message bubble
        bar.append(like, dislike);
        bubble.insertAdjacentElement("afterend", bar);

        /**
         * Handles click events for Like and Dislike buttons.
         * @param {Boolean} isLike Indicates whether the user clicked Like (true) or Dislike (false).
         */
        const onClick = (isLike) => {
          try {
            // Log the rating event with message details
            console.log('Message', messageId, isLike ? '👍' : '👎', 'Text: ' + text);

            // Construct feedback payload to send back to the bot
            const feedback = {
              text: '',
              data: {
                messageId: messageId,
                rating: isLike,
                event: "message_rating_event"
              }
            }

            // Send the feedback to Cognigy
            webchat.sendMessage("", feedback);

            // Disable buttons after rating
            like.disabled = true;
            dislike.disabled = true;

            // Visually indicate the selected option
            if (isLike) like.classList.add("selected");
            else dislike.classList.add("selected");
          } catch (err) {
            console.error("❌ Error sending feedback:", err);
          }
        };

        // Attach click handlers to both buttons
        like.addEventListener("click", () => onClick(true));
        dislike.addEventListener("click", () => onClick(false));

      } catch (err) {
        console.error("❌ Error in addLikeDislikeButtons:", err);
      }
    }

    /**
     * Registers a custom analytics service to listen for specific webchat events.
     * The main goal is to attach Like/Dislike buttons to each bot message dynamically after it is rendered.
     */
    webchat.registerAnalyticsService((event) => {
      try {
        if (event.type === 'webchat/open') {
          /**
           * When page is reloaded, re-apply Like/Dislike buttons
           * to all existing bot messages from restored session.
           */
          setTimeout(() => {
            try {
              const messages = document.querySelectorAll(".webchat-message-row.bot");
              messages.forEach((msg) =>
                addLikeDislikeButtons(msg, msg.childNodes[1]?.textContent || "", webchat)
              );
              console.log("♻️ Like/Dislike re-applied on restored messages:", messages.length);
            } catch (err) {
              console.error("❌ Error re-applying buttons on open:", err);
            }
          }, 300);
        } else if (event.type === "webchat/incoming-message") {
          // Proceed only for incoming bot messages
          const payload = event.payload;
          if (payload?.source !== "bot") return;
          const messageId = payload?.data?.message_id || "";

          // Extracts message content from Cognigy’s message structure
          const c = payload?.data?._cognigy || {};
          const web = c._webchat?.message || {};
          const def = c._default || {};
          const text =
            payload.text ||
            web.text ||
            def?._quickReplies?.text ||
            def?._raw?.text ||
            def?._html?.html?.replace(/<[^>]+>/g, " ").trim() ||
            "";

          /**
           * Waits briefly to ensure that the bot message DOM element is rendered
           * before inserting the Like/Dislike buttons.
           */
          setTimeout(() => {
            try {
              // Select all bot message elements and pick the last one
              const messages = document.querySelectorAll(".webchat-message-row.bot");
              const lastBotMessage = messages[messages.length - 1];
              if (!lastBotMessage) return;

              const message_id_DOM = lastBotMessage.getAttribute("data-message-id");
              localStorage.setItem(message_id_DOM, messageId);

              // Attach Like/Dislike buttons to the last bot message
              addLikeDislikeButtons(lastBotMessage, text, webchat);
              console.log("👍 Like/Dislike added for new message:", messageId);
            } catch (err) {
              console.error("❌ Error attaching Like/Dislike to new message:", err);
            }
          }, 200);
        } else {
          return;
        }
      } catch (err) {
        console.error("❌ Error in registerAnalyticsService event handler:", err);
      }
    });
  } catch (err) {
    console.error("❌ Fatal error initializing Like/Dislike plugin:", err);
  }
}, 200);
